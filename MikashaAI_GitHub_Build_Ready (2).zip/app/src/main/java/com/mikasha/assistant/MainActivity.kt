package com.mikasha.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private lateinit var status: TextView
    private val purple = 0xFF7C3AED.toInt()
    private val dark = 0xFF180B2B.toInt()
    private val lavender = 0xFFF3E8FF.toInt()
    private val micRequest = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 28)
            setBackgroundColor(dark)
        }

        val title = TextView(this).apply {
            text = "💜 MIKASHA"
            textSize = 32f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "आपकी पर्सनल AI असिस्टेंट"
            textSize = 17f
            setTextColor(lavender)
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 26)
        }
        status = TextView(this).apply {
            text = "नमस्ते! मैं Mikasha हूँ 💜\\nबात करने के लिए नीचे बटन दबाएँ।"
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(10, 18, 10, 26)
        }
        val talk = button("🎙️  Mikasha से बात करें") { listen() }
        val help = button("क्या कर सकती हूँ?") {
            say("मैं अभी आवाज़ से कुछ आसान काम कर सकती हूँ। आप कह सकती हैं, यूट्यूब खोलो, व्हाट्सऐप खोलो, या किसी नंबर पर कॉल करो।")
        }
        val disclaimer = TextView(this).apply {
            text = "शुरुआती संस्करण • कुछ सुविधाओं के लिए अनुमति और इंटरनेट चाहिए"
            textSize = 12f
            setTextColor(0xFFD8B4FE.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 0)
        }

        root.addView(title, matchWrap())
        root.addView(subtitle, matchWrap())
        root.addView(status, matchWrap())
        root.addView(talk, matchWrap())
        root.addView(help, matchWrap())
        root.addView(disclaimer, matchWrap())
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 14 }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 16f
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundColor(purple)
        setOnClickListener { action() }
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            val resultHindi = tts.setLanguage(Locale("hi", "IN"))
            if (resultHindi == TextToSpeech.LANG_MISSING_DATA ||
                resultHindi == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.language = Locale("en", "IN")
            }
            tts.setSpeechRate(0.92f)
            say("नमस्ते, मैं मिकाशा हूँ।")
        }
    }

    private fun say(message: String) {
        status.text = message
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "mikasha")
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), micRequest)
            return
        }
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "बोलिए, Mikasha सुन रही है")
            }
            startActivityForResult(intent, 102)
        } catch (_: Exception) {
            say("माफ़ कीजिए, इस फोन में आवाज़ पहचानने की सुविधा उपलब्ध नहीं है।")
        }
    }

    @Deprecated("Uses activity result API for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 102 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            status.text = "आपने कहा: $spoken"
            handleCommand(spoken.lowercase(Locale.ROOT))
        }
    }

    private fun handleCommand(command: String) {
        when {
            command.contains("youtube") || command.contains("यूट्यूब") -> openApp("com.google.android.youtube", "यूट्यूब खोल रही हूँ।")
            command.contains("whatsapp") || command.contains("व्हाट्सऐप") || command.contains("व्हाट्सएप") ->
                openApp("com.whatsapp", "व्हाट्सऐप खोल रही हूँ।")
            command.contains("chrome") || command.contains("क्रोम") ->
                openApp("com.android.chrome", "क्रोम खोल रही हूँ।")
            command.contains("कॉल") || command.contains("call") -> {
                val digits = Regex("[0-9]{6,}").find(command)?.value
                if (digits != null) {
                    say("कॉल स्क्रीन खोल रही हूँ। कॉल करने से पहले नंबर जाँच लें।")
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits")))
                } else {
                    say("कृपया संपर्क का नंबर बोलें, या फोन ऐप में संपर्क चुनें।")
                    startActivity(Intent(Intent.ACTION_DIAL))
                }
            }
            command.contains("मैसेज") || command.contains("message") || command.contains("संदेश") -> {
                say("मैसेज लिखने की स्क्रीन खोल रही हूँ। भेजने से पहले संदेश जाँच लें।")
                startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING))
            }
            command.contains("समय") || command.contains("time") ->
                say("अभी समय " + java.text.SimpleDateFormat("h:mm a", Locale("hi", "IN")).format(java.util.Date()) + " है।")
            command.contains("नमस्ते") || command.contains("हेलो") || command.contains("hello") ->
                say("नमस्ते! आप कैसी हैं? बताइए, मैं आपकी क्या मदद करूँ?")
            else -> say("मैंने सुना: $command। अभी मैं सीमित कमांड समझती हूँ। अधिक AI सुविधाएँ अगले संस्करण में जोड़नी होंगी।")
        }
    }

    private fun openApp(packageName: String, message: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            say(message)
            startActivity(launch)
        } else {
            say("यह ऐप आपके फोन में नहीं मिला।")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == micRequest && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            listen()
        } else if (requestCode == micRequest) {
            Toast.makeText(this, "बात करने के लिए माइक्रोफोन अनुमति दें।", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
